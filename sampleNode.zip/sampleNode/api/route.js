'use strict';

module.exports = function(app){
 let newUser = require('../controllers/userController');

//  app.get('/user',(req,res)=>{
//      res.send(newUser.demo);
//  })

// app.get('/user',(req,res)=>{
// res.send('hello this server listening on 9000 port');


// })
app.route("/user")
.get(newUser.demo);
 

}