'use strict';

let mongoose = require('mongoose');
let User = mongoose.model('Users');

 exports.demo = (req,res)=>{
  //   var userData = [
  //    { username: 'John', password: 'Highway', confirmPassword: ' secondpasttsowrd'},
  //    { username: 'Jodhn', password: 'Hitgghway', confirmPassword: ' secondpass44ttowrd'},
  //    { username: 'Joshn', password: 'Highghway', confirmPassword: ' secondggpassowrd'},
  //    { username: 'Johfn', password: 'Highfeway', confirmPassword: ' secontyrdpaggssowrd'},
  //    { username: 'Joghn', password: 'Highwe3ay', confirmPassword: ' seggcondpassowrd'},
  //    { username: 'Jojhn', password: 'High3wway', confirmPassword: ' seggcondpassowrd'},
  //    { username: 'Jobhn', password: 'Highwgfhay', confirmPassword: ' secondpassggowrd'},
  //    { username: 'Joehn', password: 'Highhfhway', confirmPassword: ' secondpasggsowrd'},
  //    { username: 'Johgn', password: 'Highghway', confirmPassword: ' seconggdpassowrd'},
 
  //  ];
   const data ={ username: 'John',
    password: 'Highway', 
    confirmPassword: ' secondpasttsowrd'}

 
    //  User.insertMany(userData,function(err,res){
    //    if(err) throw err;
    //    console.log("Document inserted:"+res.insertedCount);
    //  })
    //  User.find({},function(err,result){
    //    if(err) throw err 
    //    console.log(result)
    //  })

   // console.log('demo function called');
     res.json(data);
   }
  