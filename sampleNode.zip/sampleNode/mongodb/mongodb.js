var mongoose = require('mongoose');

const server = '127.0.0.1';
const database = 'twobrothers';

class Database {
  
    constructor(http){
        this._connect(http)
    }
    _connect(http){
        mongoose.connect(`mongodb://${server}/${database}`,{useNewUrlParser:true,useUnifiedTopology:true,useCreateIndex:true})
        .then(()=>{
         //   require('../socket/socket')(http)
            console.log('database connected')
            
        })
        .catch(err =>{
            console.error('database connection error',err)
        })
    }

}
module.exports =(http)=> new Database(http)
