const app = require('express')();
const http = require('http').createServer(app);





//mongo.Collection('')
const BodyParser = require('body-parser');
app.use(BodyParser.json());
app.use(BodyParser.urlencoded({ extended: true}));

require('./mongodb/mongodb')(http);
require('./models/UserModel');

let routes = require('./api/route')
routes(app);

app.listen(9000);
console.log("listening to 9000 port")

// app.get('/',(req,res)=>{
// res.send('hello this server listening on 9000 port');


// })
